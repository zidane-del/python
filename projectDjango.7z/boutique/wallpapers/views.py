#EXEMPLE SIMPLE A VOIR
"""from django.shortcuts import render
from django.http import HttpResponse#reponse a une requete http

# Create your views here.
#program principal de la page
#request est une http request donc obliji de declarer ce parametre pour recevoir la requete

#FIRST THING TO DO AS AN EXEMPLE TO VIEW THIS FUNCTION
def index(request):
    return HttpResponse("hello world")

#boutique/acceuil/index par exemple
# SECOND THING TO DO IS GO TO URL.PY ET FAIRE CORRESPONDRE THIS PAGE
#BY CREATING A  NEW PYTHON SCRIPT CALLED URLS
"""
"""quand on definie une function ici pour faire une requete http 
il faut lui faire correspondre une url (donc url mapping)
pour que django comprenent que quand il ya une navigation a 
exemple 
http/boutique/index il sera quil doit venir ici 
et afficher le contenu retourner par la function index 
"""
"""
#DEFINE AN OTHER PAGE AS EXERCICE
def nouvell(request):
    return HttpResponse('ceci est un autre message venant de cette function')

"""

from django.shortcuts import render
from django.http import HttpResponse#reponse a une requete http
from .models import Wallpapers

# Create your views here.
#program principal de la page
#request est une http request donc obliji de declarer ce parametre pour recevoir la requete

#FIRST THING TO DO AS AN EXEMPLE TO VIEW THIS FUNCTION
def index(request):
    wall=Wallpapers.objects.all()#recuperer touts les element de notre base de donnée
    return render(request, 'index.html',
                  {'MyWallpapers': wall})

#boutique/acceuil/index par exemple
# SECOND THING TO DO IS GO TO URL.PY ET FAIRE CORRESPONDRE THIS PAGE
#BY CREATING A  NEW PYTHON SCRIPT CALLED URLS
"""
quand on definie une function ici pour faire une requete http 
il faut lui faire correspondre une url (donc url mapping)
pour que django comprenent que quand il ya une navigation a 
exemple 
http/boutique/index il sera quil doit venir ici 
et afficher le contenu retourner par la function index 
"""

#DEFINE AN OTHER PAGE AS EXERCICE
def nouvell(request):
    return HttpResponse('ceci est un autre message venant de cette function')

