from django.contrib import admin
from .models import Wallpapers,Promotion,Age

# Register your models here.

class WallpapersAdmin(admin.ModelAdmin):
    list_display = ('author', 'price', 'contite')

class promotionAdmin(admin.ModelAdmin):
    list_display = ('code', 'description','promotion')


class AgeAdmin(admin.ModelAdmin):
    list_display = ('nom', 'prenom')


admin.site.register(Wallpapers, WallpapersAdmin)
admin.site.register(Promotion,promotionAdmin)
admin.site.register(Age,AgeAdmin)