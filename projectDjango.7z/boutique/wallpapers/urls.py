from django.urls import path
from . import views
urlpatterns = [
    path('', views.index),#this means the root so /boutique
    path('nouvelle', views.nouvell)
]