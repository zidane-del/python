from django.db import models

# Create your models here.
#MODEL.MODEL CONTIENT DES MODULE NECESSAIRE COMME LES BASES DE DONN2E
#c'est comme tkinter qui contient des widget


class Wallpapers(models.Model):
    author = models.CharField(max_length=255)
    price = models.FloatField()
    contite = models.IntegerField()
    image = models.CharField(max_length=2083)

class Promotion(models.Model):
    code = models.CharField(max_length=255)
    description = models.CharField(max_length=255)
    promotion = models.FloatField()

class Age(models.Model):
    nom = models.CharField(max_length=255)
    prenom = models.CharField(max_length=255)
